
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import RolesSection from '@/components/RolesSection';
import WhyJoinSection from '@/components/WhyJoinSection';
import ProcessSection from '@/components/ProcessSection';
import CTAFooter from '@/components/CTAFooter';

const Index = () => {
  return (
    <div className="min-h-screen bg-white">
      <HeroSection />
      <AboutSection />
      <RolesSection />
      <WhyJoinSection />
      <ProcessSection />
      <CTAFooter />
    </div>
  );
};

export default Index;
