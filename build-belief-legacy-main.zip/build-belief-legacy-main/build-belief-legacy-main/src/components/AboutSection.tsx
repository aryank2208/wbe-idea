
const AboutSection = () => {
  const logos = [
    "HASH GUYS",
    "FAKiRi", 
    "wake",
    "InheritIQ",
    "StyledBy"
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-black mb-8">
          ABOUT BWE
        </h2>
        <p className="text-xl text-gray-700 mb-16 max-w-4xl leading-relaxed">
          BWE Studios isn't an agency or incubator. We co-create legendary startups by pairing high-agency talent with execution-first systems. Our belief: the future belongs to those who build it.
        </p>
        
        <div className="flex flex-wrap items-center justify-center md:justify-start gap-8 md:gap-12">
          {logos.map((logo, index) => (
            <div 
              key={logo}
              className="text-2xl md:text-3xl font-bold text-gray-400 hover:text-black transition-colors duration-300"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              {logo}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
