
import { Button } from '@/components/ui/button';

const CTAFooter = () => {
  return (
    <section className="py-20 bg-black text-white">
      <div className="max-w-4xl mx-auto text-center px-4">
        <h2 className="text-4xl md:text-6xl font-bold mb-12 leading-tight">
          Build legacy, not just portfolios.
        </h2>
        <Button 
          size="lg" 
          className="bg-purple-600 hover:bg-purple-700 text-white px-12 py-6 text-xl font-semibold transition-all duration-300 hover:scale-105"
        >
          APPLY NOW TO BUILD WITH ESHAAN
        </Button>
      </div>
    </section>
  );
};

export default CTAFooter;
