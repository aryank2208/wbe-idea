
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Users, Code, Star, Rocket, Briefcase, Heart } from 'lucide-react';

const RolesSection = () => {
  const roles = [
    {
      title: "Ops & Comms Lead",
      description: "Systems, meetings, momentum, execution",
      icon: Users,
    },
    {
      title: "AI Product Builder",
      description: "MVPs, sprints, backend logic",
      icon: Code,
    },
    {
      title: "Creative Director", 
      description: "Visual, brand, storytelling",
      icon: Star,
    },
    {
      title: "Growth Hacker",
      description: "Hook creation, virality loops",
      icon: Rocket,
    },
    {
      title: "Founder's Associate",
      description: "Tactical execution, strategic executor",
      icon: Briefcase,
    },
    {
      title: "Community & Backer Manager",
      description: "Relationship building, member experience",
      icon: Heart,
    },
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold text-black mb-16 text-center">
          ROLES WE'RE HIRING
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {roles.map((role, index) => (
            <Card 
              key={role.title}
              className="border-2 border-gray-200 hover:border-purple-600 transition-all duration-300 hover:shadow-lg"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-4">
                  <role.icon className="w-8 h-8 text-purple-600 mr-3" />
                  <h3 className="text-xl font-bold text-black">{role.title}</h3>
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed">
                  {role.description}
                </p>
                <Button 
                  variant="outline" 
                  className="w-full border-purple-600 text-purple-600 hover:bg-purple-600 hover:text-white"
                >
                  APPLY NOW
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RolesSection;
