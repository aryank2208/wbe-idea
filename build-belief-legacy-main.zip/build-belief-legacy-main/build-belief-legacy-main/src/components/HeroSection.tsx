
import { Button } from '@/components/ui/button';

const HeroSection = () => {
  return (
    <section className="min-h-screen bg-black text-white flex items-center justify-center px-4">
      <div className="max-w-4xl mx-auto text-center animate-fade-in">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          EQUITY FOR CREATORS.
          <br />
          ROI FOR BELIEVERS.
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
          Join the venture studio building iconic startups across AI, food, fashion, and fintech — with no VC, just belief.
        </p>
        <Button 
          size="lg" 
          className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-4 text-lg font-semibold transition-all duration-300 hover:scale-105"
        >
          APPLY TO JOIN THE STUDIO
        </Button>
      </div>
    </section>
  );
};

export default HeroSection;
