
import { Check } from 'lucide-react';

const WhyJoinSection = () => {
  const benefits = [
    "Work on 15+ live ventures",
    "Equity & rev share, not just salary", 
    "AI-first workflows & access",
    "Weekly sprints, full credits, no fluff"
  ];

  return (
    <section className="py-20 bg-black text-white">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl md:text-5xl font-bold mb-16">
          WHY JOIN
        </h2>
        
        <div className="space-y-6">
          {benefits.map((benefit, index) => (
            <div 
              key={benefit}
              className="flex items-center text-xl md:text-2xl animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <Check className="w-8 h-8 text-purple-600 mr-6 flex-shrink-0" />
              <span className="leading-relaxed">{benefit}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyJoinSection;
